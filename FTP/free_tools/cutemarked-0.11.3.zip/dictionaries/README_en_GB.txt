Original version of the en_GB dictionary:
http://www.openoffice.org/issues/show_bug.cgi/id=72145

OpenOffice.org patch and morphological extension

The morphological extension based on Wordlist POS and AGID data
created by Kevin Atkinson and released on http://wordlist.sourceforge.net.

Other fixes:

OOo Issue 48060 - add numbers with affixes by COMPOUNDRULE (1st, 111th, 1990s etc.)
OOo Issue 29112, 55498 - add NOSUGGEST flags to taboo words
New REP items (better suggestions for accented words and a few mistakes)
OOo Issue 63541 - remove *dessicated

2008-12-18 nemeth AT OOo

Original license:

This dictionary was initially based on a subset of the 
original English wordlist created by Kevin Atkinson for 
Pspell and  Aspell and thus is covered by his original 
LGPL licence. 

It has been extensively updated by David Bartlett, Brian Kelk
and Andrew Brown:
- numerous Americanism have been removed
- numerous American spellings have been corrected
- missing words have been added
- many errors have been corrected
- compound hyphenated words have been added where appropriate

Valuable inputs to this process were received from many other 
people - far too numerous to name. Serious thanks to you all
for your greatly appreciated help.

This word list is intended to be a good representation of
current modern British English and thus it should be a good 
basis for Commonwealth English in most countries of the world 
outside North America.

The affix file has been created completely from scratch
by David Bartlett and Andrew Brown, based on the published 
rules for MySpell and is also provided under the LGPL.

In creating the affix rules an attempt has been made to 
reproduce the most general rules for English word
formation, rather than merely use it as a means to
compress the size of the dictionary. It is hoped that this
will facilitate future localisation to other variants of
English.

Please let David Bartlett <dwb@openoffice.org> know of any 
errors that you find.

The current release is R 1.20, 30/11/2006
